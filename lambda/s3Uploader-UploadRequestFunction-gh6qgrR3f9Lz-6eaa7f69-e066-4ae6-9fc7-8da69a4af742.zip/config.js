/**
 * working with api in lambda
 * for testing purpose only
 */

module.exports = {
  "UploadBucket" : "s3uploader-s3uploadbucket-na0z96kezgv2",
  "CloudfrontDDN" : "https://d2m208l1e45tmg.cloudfront.net"
};
// JavaScript File
